<?php
include_once ('config.php');

if(isset($_POST['submit'])){

   $category = $_POST['category'];
   $taquilla = $_POST['taquilla'];

   $product = $_POST['product'];
   $model = $_POST['model'];
   $observation = $_POST['observation'];
   $product = $_POST['product'];
   $pdffile = $_FILES['pdffile'];
   $inpFile = $_FILES['inpFile'];

   //Image Files
   $imageName = $inpFile['name'];
   $imgFileType = $inpFile['type'];
   $imgFileSize = $inpFile['size'];
   $imgFileData = explode('/',$imgFileType);
   $imgFileExtension = $imgFileData[count($imgFileData)-1];
   $imgFileTmpName = $inpFile['tmp_name'];
   $imgFileError = $inpFile['error'];

   //PDF File
   $pdfName = $pdffile['name'];
   $pdfFileType = $pdffile['type'];
   $pdfFileSize = $pdffile['size'];
   $pdfFileData = explode('/',$imgFileType);
   $pdfFileExtension = $pdfFileData[count($pdfFileData)-1];
   $pdfFileTmpName = $pdffile['tmp_name'];
   $pdfFileError = $pdffile['error'];
    

   if($taquilla =='Select Taquilla' || $category =='Select Category'){
        header('location: add_item.php?error=CategoryAndTaquilla');
        exit;
   }

   if(!empty($pdfName)){
            if($pdfFileSize<10000000){
                $pdfFileName = "public/pdfFiles/". $pdfName;
                $pdfFileUploaded = move_uploaded_file($pdfFileTmpName,$pdfFileName);

                if($pdfFileUploaded){

                }else{
                    echo 'PDF file cannot be upload';
                }
            }else{
                header('location: add_item.php?error=invalidPDFFileSize');
                exit;
            }
   }


    if($imgFileExtension == 'jpg' || $imgFileExtension == 'png' || $imgFileExtension == 'jpeg'){
        
        if($imgFileSize< 8000000){
            $imgFileName = "public/userImages/". $imageName;
            $imgFileUploaded = move_uploaded_file($imgFileTmpName,$imgFileName);

            if($imgFileUploaded){
                
                if(!empty($pdfName)){
                    $sql = "INSERT INTO items (item_img,category,tranquilla,product,model,observations,pdf_file,created_at)
                    VALUES ('$imageName','$category','$taquilla','$product','$model','$observation','$pdfName',NOW())";
                    
                    $results = mysqli_query($conn,$sql);
                
                    header('location: add_item.php?success=postUploaded');
                }else{
                    $sql = "INSERT INTO items (item_img,category,tranquilla,product,model,observations,pdf_file,created_at)
                VALUES ('$imageName','$category','$taquilla','$product','$model','$observation','null',NOW())";
                
                $results = mysqli_query($conn,$sql);
            
                header('location: add_item.php?success=postUploaded');
                }
                
                
            }else { echo 'Cannot upload file'; }

        }else{
            header('location: add_item.php?error=invalidFileSize');
            exit;
        }
        var_dump($imgFileSize);
        
    }else{
        header('location: add_item.php?error=invalidFileType');
        exit;
    }

   
    
}

//item_id
//item_img
//category
//tranquilla
//product
//model
//observations
//pdf_file
//created_at

?>