<?php

//ultbitco_invent_new
//_7k7tzr_jPE3
//_7k7tzr_jPE3

$servername = "localhost";
$username = "ultbitco_invent_new";
$password = "_7k7tzr_jPE3";
$dbname = "ultbitco_inventory";

$conn = mysqli_connect("localhost", "ultbitco_invent_new", "_7k7tzr_jPE3", "ultbitco_inventory");
 
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}



?>