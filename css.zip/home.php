<?php

include_once ('config.php');



if(isset($_POST["submit"]))
{

    //echo "if result CHECK ";

    $searchcategory = $_POST['searchcategory'];
    $searchtaquilla = $_POST['searchtaquilla'];
    $searchproduct = $_POST['searchproduct'];
    $searchmodel = $_POST['searchmodel'];

    if(!empty($searchcategory) && !empty($searchtaquilla) && !empty($searchproduct) && !empty($searchmodel))
    {
        
        $sql = "SELECT * FROM items WHERE category LIKE '%$searchcategory%' AND tranquilla LIKE '%$searchtaquilla%' 
        AND product LIKE '%$searchproduct%' AND model LIKE '%$searchmodel%'" ;
        $result = $conn->query($sql);
       
    
    }else if(!empty($searchcategory))
    {
        $sql = "SELECT * FROM items WHERE category LIKE '%$searchcategory%'" ;
        
        $result = $conn->query($sql);
    }else if(!empty($searchtaquilla))
    {
        $sql = "SELECT * FROM items WHERE tranquilla LIKE '%$searchtaquilla%'" ;
        
        $result = $conn->query($sql);
        
    }else if(!empty($searchproduct))
    {
        $sql = "SELECT * FROM items WHERE product LIKE '%$searchproduct%'" ;
        
        $result = $conn->query($sql);
    }else if(!empty($searchmodel))
    {
        $sql = "SELECT * FROM items WHERE model LIKE '%$searchmodel%'" ;
        
        $result = $conn->query($sql);
        
        
    }
}else if(isset($_POST['submit_clear']))
{
    $sql = "SELECT * FROM items";
    $result = $conn->query($sql);
    //echo 'Clear Filter \n';
    
}
else{


    $sql = "SELECT * FROM items";
    $result = $conn->query($sql);
    //echo 'No Filter \n';
    
}










?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Inventory</title>
    <link rel="stylesheet" href="css/style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>

<body>
    <div class="container mt-3">
        <h2>All Inventory Items</h2>
        <hr>


        <div class="row mb-1">
            <div class="col">
                <div class="col"><label for=""><strong>Filters</strong></label></div>
            </div>
        </div>
        <form action="home.php" method="post">
            <div class="row mb-2">
                
                <div class="row">
                <div class="form-outline input-group mb-2 w-50">
                            
                    <input type="text" class="form-control" placeholder="Category Name" 
                    name="searchcategory" id="searchcategory" >

                </div>

                <div class="form-outline mb-2 w-50">
                            
                    <input type="text" class="form-control" placeholder="Taquilla Name" 
                    name="searchtaquilla" id="searchtaquilla" >

                </div>
            </div>    
            <div class="form-outline mb-2 w-50">
                            
                    <input type="text" class="form-control" placeholder="Product Name" 
                    name="searchproduct" id="searchproduct" >
            
                </div>
                <div class="form-outline mb-2 w-50 float-end">
                            
                    <input type="text" class="form-control" placeholder="Model Name" 
                    name="searchmodel" id="searchmodel" >
            
                </div>
            </div>
            <div class="form-outline mb-4">
                <button type="submit" name="submit" class="btn btn-primary mb-4" >Apply Filters</button>
                <button type="submit" name="submit_clear" class="btn btn-danger btn-block mb-4">Clear Filters</button>
            </div>
        </form>    
        
        <div class="row mb-4">
            
            <div class="col">
                <button type="submit" class="btn btn-primary mb-4" onclick="loadCategoryPage()">Add Category</button>
                <button type="submit" class="btn btn-primary mb-4" onclick="loadTanquillaPage()">Add Tanquilla</button>
            </div>
            <div class="col">

                <div class="float-end">

                    <button type="submit" class="btn btn-primary mb-4" onclick="loadPage()">Add Item</button>
                </div>


            </div>
        </div>



        <table class="table table-bordered table-hover">
            <thead class="table-primary">
                <tr>
                    <th>Item ID</th>
                    <th>CATEGORIA</th>
                    <th>TAQUILLA</th>
                    <th>PRODUCTO</th>
                    <th>MODELO</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    // $sql = "SELECT * FROM items";
                    // $result = $conn->query($sql);
                    
                    
                    while ($row = $result->fetch_assoc()) { 
                    
                ?>

                <tr>
                    <td><?php echo $row['item_id']; ?></td>
                    <td><?php echo $row['category']; ?></td>
                    <td><?php echo $row['tranquilla']; ?></td>
                    <?php echo '<td><a href="view_item.php?item_id='.$row['item_id'].'">'.$row['product'].'</a></td>'?>
                    <td><?php echo $row['model']; ?></td>
                    
                </tr>
                    
                <?php //endwhile;
                }
                ?>
                
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
        crossorigin="anonymous"></script>

    <script>

        function loadPage() {

            window.location = "add_item.php";

        }

        function loadCategoryPage() {

            window.location = "add_category.php";

        }

        function loadTanquillaPage() {

            window.location = "add_taquilla.php";

        }
    </script>
</body>

</html>