<?php

include_once ('config.php');

if(isset($_POST['submit'])){


    $taquilla = $_POST['taquilla'];
    
    $sql = "INSERT INTO taquillas (taquilla_name) VALUES ('$taquilla')";
    if(mysqli_query($conn, $sql)){
        echo "<script type='text/javascript'>alert('Records inserted successfully.');window.location.href='home.php';</script>";
    
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Inventory</title>
    <link rel="stylesheet" href="css/style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>




<body>


    <div class="container-fluid">


        <div class="row">
            <div class="offset-md-4 col-md-4">
                <h2>Add New Taquilla</h2>


                <form class="needs-validation" method="POST">



                    <div class="form-outline mb-4">
                        <label for="">Taquilla</label>
                        <input type="text" class="form-control" placeholder="Enter Taquilla" name="taquilla"
                            id="taquilla" required>

                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>

                    </div>



                    <div class="d-grid gap-2">

                        <button type="submit" name="submit" class="btn btn-primary btn-block mb-2">Add</button>

                    </div>


                    <div class="d-grid gap-2">

                        <button type="submit" onclick="window.history.go(-1); return false;"
                            class="btn btn-primary">Back</button>
                    </div>


                </form>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
        crossorigin="anonymous"></script>



</body>

</html>