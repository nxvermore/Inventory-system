<?php

include_once ('config.php');

//ultbitco_invent_new
//_7k7tzr_jPE3
//_7k7tzr_jPE3

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Inventory</title>
    <link rel="stylesheet" href="css/style.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>



<body>


    <div class="container-fluid">


        <div class="row">
            <div class="offset-md-4 col-md-4">
                <h2>Add New Article</h2>

               
              <?php

                if(isset($_GET['success'])){
                    if($_GET['success'] == 'postUploaded'){
                        ?>
                        <small class="alert alert-success"> Post updated successfully</small>
                        <?php
                    }
                }
                if(isset($_GET['error'])){ 
                    if($_GET['error'] == 'CategoryAndTaquilla'){
                    ?>
                        <small class="alert alert-danger"> Please select Category and Taquilla both are mandatory</small>

                        <hr>
                        <?php
                    }else if($_GET['error'] == 'invalidFileType'){
                        ?>
                        <small class="alert alert-danger"> File is not of valid extension</small>
                        <hr>

                        <?php
                    }else if($_GET['error'] == 'invalidFileSize'){
                        ?>
                        <small class="alert alert-danger"> Maximum 8mb File is allowed to upload</small>
                        <hr>

                        <?php

                    }else if($_GET['error'] == 'invalidPDFFileType'){
                        ?>
                        <small class="alert alert-danger"> PDF file is not valid</small>
                        <hr>

                        <?php
                    }else if($_GET['error'] == 'invalidPDFFileSize'){
                        ?>
                        <small class="alert alert-danger"> Maximum 10 mb PDF File is allowed to upload</small>
                        <hr>
    
                        <?php
               }
            }
              ?>

                <form action="uploadfiles.php" class="needs-validation" method="post" enctype="multipart/form-data">


                    <div class="form-outline mb-4">

                        <div class="offset-md-2 image-preview" id="imagePreview">
                            <img src="" alt="Image Preview" class="image-preview__image">
                            <span class="image-preview__default-text">Image Preview</span>
                        </div>
                        <input type="file" name="inpFile" id="inpFile" accept="image/png, image/jpeg"
                            class="form-control" required/>

                    </div>

                    <div class="form-outline mb-4">
                        <label for="">Categoria</label>
                    
                       
                        <select class="form-select" name="category" id="category">
                        <option selected>Select Category</option>
                        
                        <?php
                        $sql = "SELECT category_id, category_name FROM categories";
                        $result = $conn->query($sql);
                            while($row = $result->fetch_assoc()) {
                                echo '<option value="'.$row['category_name'].'">'.$row['category_name'].'</option>';
                                ?>
                                
                            <?php }?>
                        </select>
                      

                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>


                    </div>

                    <div class="form-outline mb-4">
                        <label for="">Taquilla</label>
                        <select class="form-select" name="taquilla" id="taquilla">
                        <option selected>Select Taquilla</option>

                        
                        <?php
                        $sql = "SELECT taquilla_id, taquilla_name FROM taquillas";
                        $result = $conn->query($sql);
                            while($row = $result->fetch_assoc()) {
                                echo '<option value="'.$row['taquilla_name'].'">'.$row['taquilla_name'].'</option>';
                                ?>
                            <?php }?>
                        </select>
                      

                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>

                    </div>

                    <div class="form-outline mb-4">
                        <label for="">Producto</label>
                        <input type="text" class="form-control" placeholder="Enter Product" name="product"
                            id="product" required>

                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>


                    </div>

                    <div class="form-outline mb-4">
                        <label for="">Modelo</label>
                        <input type="text" class="form-control" placeholder="Enter Model" name="model" id="model"
                            required>

                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>


                    </div>
                    <div class="form-outline mb-4">
                        <label for="">Upload PDF</label>
                        <input type="file" accept="application/pdf" class="form-control" name="pdffile" id="pdffile">

                        <div class="valid-feedback">Valid.</div>
                        <div class="invalid-feedback">Please fill out this field.</div>
                    </div>

                    <div class="form-outline mb-4">
                        <label class="form-label" for="textAreaExample">Observaciones</label>
                        <textarea class="form-control" name="observation" id="observation" rows="4"></textarea required>
                    </div>

                    <div class="d-grid gap-2">

                        <button type="submit" name="submit" class="btn btn-primary btn-block mb-4">Add</button>

                    </div>
                    
                     <div class="d-grid gap-2">

                        <button type="button" onClick="document.location.href='home.php'" class="btn btn-primary btn-block mb-4">Home</button>

                    </div>



                </form>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
        crossorigin="anonymous"></script>


    <script>
        const inpFile = document.getElementById("inpFile");
        const previewContainer = document.getElementById("imagePreview");
        const previewImage = previewContainer.querySelector(".image-preview__image");
        const previewDefualtText = previewContainer.querySelector(".image-preview__default-text");

        inpFile.addEventListener("change", function () {

            const file = inpFile.files[0];
            console.log(file);

            if (file) {
                const reader = new FileReader();

                previewDefualtText.style.display = "none";
                previewImage.style.display = "block";

                reader.addEventListener("load", function () {
                    previewImage.setAttribute("src", this.result);
                });

                reader.readAsDataURL(file);
            } else {
                previewDefualtText.style.display = null;
                previewImage.style.display = null;
                previewImage.setAttribute("src", "");
            }





        });
    </script>




</body>

</html>