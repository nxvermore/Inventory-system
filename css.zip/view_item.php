<?php
include_once ('config.php');

if(isset($_POST['delete'])){
    $itemID = $_GET['item_id'];
    $sql = "DELETE FROM items WHERE item_id= '$itemID'";
    if(mysqli_query($conn, $sql)){
        echo "<script type='text/javascript'>alert('Item deleted successfully.');window.location.href='home.php';</script>";
    
    } else{
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
    }



}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Inventory</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</head>



<body>


    <div class="container-fluid">


        <div class="row">
            <div class="offset-md-4 col-md-4">
                <h2>Product Detail</h2>


                <?php

                if(isset($_GET['item_id'])){

                    $itemID = $_GET['item_id'];
                    $sql = "SELECT * FROM items WHERE item_id=".$itemID;
                        $result = $conn->query($sql);
                        while($row = $result->fetch_assoc()) {
                            $item_ID = $row['item_id'];
                            $item_img = 'public/userImages/'.$row['item_img'];
                            $category = $row['category'];
                            $tranquilla = $row['tranquilla'];
                            $product = $row['product'];
                            $model = $row['model'];
                            $observations = $row['observations'];
                            
                         }
                }
                ?>

                <form action="" method="POST">


                    <div class="form-outline mb-4">
                        <img src="<?php echo $item_img; ?>" style="width: 300px; min-height: 150px;" alt="Image Preview"
                            class="image-preview__image">

                    </div>

                    <div class="form-outline mb-4">
                        <label for="">Categoria</label>
                        <input type="text" class="form-control" value='<?php echo $category;?>' readonly>

                    </div>

                    <div class="form-outline mb-4">
                        <label for="">Taquilla</label>
                        <input type="text" class="form-control" value='<?php echo $tranquilla;?>' readonly>

                    </div>

                    <div class="form-outline mb-4">
                        <label for="">Producto</label>
                        <input type="text" class="form-control" value='<?php echo $product;?>' readonly>

                    </div>

                    <div class="form-outline mb-4">
                        <label for="">Modelo</label>
                        <input type="text" class="form-control" value='<?php echo $model;?>' readonly>

                    </div>

                    <div class="form-outline mb-4">
                        <label class="form-label" for="textAreaExample">Observaciones</label>
                        <textarea class="form-control" id="textAreaExample1" rows="4" readonly
                            ><?php echo $observations;?></textarea>
                    </div>

                    <div class="d-grid gap-2">

                        <button type="submit" name="delete"
                            class="btn btn-danger btn-block mb-2">Delete</button>
                    </div>

                    <div class="d-grid gap-2">

                        <button type="submit" onclick="window.history.go(-1); return false;"
                            class="btn btn-primary btn-block mb-4">Back</button>
                    </div>




                </form>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
        integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"
        integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V"
        crossorigin="anonymous"></script>


</body>

</html>